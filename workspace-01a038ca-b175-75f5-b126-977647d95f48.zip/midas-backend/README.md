# Backend local MIDAS-Bénin

Backend de démonstration académique : Fastify + TypeScript + SQLite.

**Prérequis : Node.js 24 ou version plus récente.** Le backend utilise le module SQLite intégré à Node.js 24 et ne requiert plus `better-sqlite3`, node-gyp ou Visual Studio C++.

## Exécution

```bash
npm install
npm run check
npm run start
```

Le serveur écoute sur `http://0.0.0.0:3000` et crée `data/midas.db`.

## Connexion depuis le téléphone Android

- **Émulateur Android** : conservez `http://10.0.2.2:3000` dans `midas-android/app/build.gradle.kts`.
- **Téléphone physique** : PC et téléphone doivent être sur le même Wi-Fi. L’application MIDAS essaie automatiquement `192.168.1.199` puis `192.168.1.200` et mémorise celle qui répond.
- Le fichier `Lancer_MIDAS_Backend.bat` détecte et affiche l’adresse IPv4 actuelle du PC au démarrage.
- Autorisez le port TCP `3000` dans le pare-feu Windows pour le réseau privé.

> Données synthétiques uniquement. Ce projet ne vérifie pas réellement un NPI auprès de l'ANIP et ne doit pas être déployé comme service public.
